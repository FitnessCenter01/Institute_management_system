<?php
session_start();
$con=mysqli_connect("localhost","root","","i_m_s");

?>